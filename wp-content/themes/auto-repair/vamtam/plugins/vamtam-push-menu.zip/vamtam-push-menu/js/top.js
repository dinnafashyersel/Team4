(function($, undefined) {
	"use strict";

	var PM = {
		Models: {},
		Collections: {},
		Views: {}
	};
